package model;


public class Produto {
    
}
